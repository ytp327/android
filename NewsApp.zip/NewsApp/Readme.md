<h1>News App</h1>
<p>This app is used to display the news on Internet. It uses API to receive data from the Internet.</p>